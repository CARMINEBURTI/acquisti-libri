/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.libreria;

/**
 *
 * @author Studente
 */
public class Acquisti {
    private Acquisto[] lista;
    
    public Acquisti(int dimensioneIniziale) {
        lista = new Acquisto[dimensioneIniziale];
    }
    
    public Acquisto[] getLista() {
        return lista;
    }
    
    public void setLista(Acquisto[] lista) {
        this.lista = lista;
    }
    
    public void aggiungiAcquisto(Acquisto acquisto) {
        Acquisto[] nuovaLista = new Acquisto[lista.length + 1];
        for (int i = 0; i < lista.length; i++) {
            nuovaLista[i] = lista[i];
        }
        nuovaLista[lista.length] = acquisto;
        lista = nuovaLista;
    }
    
    public int cerca(Acquisto a) {
        int x = -1;
        for (int i = 0; i < lista.length; i++) {
            if (a.getUtente().equals(lista[i].getUtente()) && a.getLista().equals(lista[i].getLista()) && a.getData()==lista[i].getData()) {
                x = i;
                break;
            }
        }
        return x;
    }
}

