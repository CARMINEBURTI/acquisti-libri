/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.libreria;

/**
 *
 * @author Studente
 */
public class Utenti {
    private Utente lista[];

    public Utenti(Utente[] lista) {
        setLista(lista);
    }

    public Utenti(int dimensione) {
        lista = new Utente[dimensione];
    }

    public void setLista(Utente[] lista) {
        int dimensione = lista.length;
        this.lista = new Utente[dimensione];
        for (int i = 0; i < dimensione; i++) {
            this.lista[i] = lista[i];
        }
    }

    public void addUtente(int i, String nome, String cognome, String email, String password) {
        lista[i] = new Utente(nome, cognome, email, password);
    }

    public int cerca(Utente utente) {
        int x = -1;
        for (int i = 0; i < lista.length; i++) {
            Utente listaUtente = lista[i];
            if (utente.getNome().equals(listaUtente.getNome()) && utente.getCognome().equals(listaUtente.getCognome()) && utente.getEmail().equals(listaUtente.getEmail()) && utente.getPassword().equals(listaUtente.getPassword())) {
                x = i;
                break;
            }
        }
        return x;
    }
}

