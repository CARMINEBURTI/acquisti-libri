/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.libreria;

/**
 *
 * @author Studente
 */
public class Libri {
    private Libro lista[];

    public Libri(Libro[] lista) {
        setLista(lista);
    }

    public Libri(int dimensione) {
        lista = new Libro[dimensione];
    }

    public void setLista(Libro[] lista) {
        int dimensione = lista.length;
        this.lista = new Libro[dimensione];
        for (int i = 0; i < dimensione; i++) {
            this.lista[i] = lista[i];
        }
    }

    public void addLibro(int i, String titolo, String autore, float prezzo) {
        lista[i] = new Libro(titolo, autore, prezzo);
    }

    public int cerca(Libro a) {
        int x = -1;
        for (int i = 0; i < lista.length; i++) {
            if (a.getTitolo().equals(lista[i].getTitolo()) && a.getAutore().equals(lista[i].getAutore())
                    && a.getPrezzo() == lista[i].getPrezzo()) {
                x = i;
                break;
            }
        }
        return x;
    }

    Libro[] getLista() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}

   
